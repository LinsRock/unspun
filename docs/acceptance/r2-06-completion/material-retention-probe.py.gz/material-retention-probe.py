"""Prove the original body survives an ambient R1 source refresh before deployment."""
import hashlib
import json
from sqlalchemy import select, text
from sqlalchemy.orm import Session
from unspun.core.db import get_engine
from unspun.core.models import Article, ContentDerivation, ContentMaterial

with get_engine().connect().execution_options(isolation_level='REPEATABLE READ') as connection, connection.begin():
    connection.execute(text('SET TRANSACTION READ ONLY'))
    with Session(bind=connection) as session:
        article=session.get(Article,9334)
        out={'article_id':9334,'current_material_id':article.current_material_id,'read_only':connection.scalar(text('SHOW transaction_read_only')),'materials':[],'derivations':[],'provider_queries':0,'database_writes':0}
        for material in session.scalars(select(ContentMaterial).where(ContentMaterial.article_id==9334).order_by(ContentMaterial.id)):
            body='\n'.join(row['text'] for row in material.paragraphs)
            out['materials'].append({'id':material.id,'scope':material.scope,'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'text_fingerprint':material.text_fingerprint,'metadata_fingerprint':material.metadata_fingerprint,'retrieved_at':material.retrieved_at})
        for row in session.scalars(select(ContentDerivation).where(ContentDerivation.article_id==9334).order_by(ContentDerivation.id)):
            out['derivations'].append({name:getattr(row,name) for name in ('id','material_id','kind','status','created_at','updated_at')})
        print(json.dumps(out,indent=2,default=str))
