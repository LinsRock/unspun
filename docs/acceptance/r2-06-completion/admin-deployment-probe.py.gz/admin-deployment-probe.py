"""Read-only verification of the deployed admin route, assets and authorization."""
import hashlib
import json
import subprocess
import urllib.error
import urllib.request
from datetime import UTC, datetime

out = {"at": datetime.now(UTC).isoformat(), "provider_queries": 0, "database_writes": 0}
with urllib.request.urlopen("http://127.0.0.1:8080/admin/topics", timeout=15) as response:
    html = response.read()
    out["page_status"] = response.status
    out["page_sha256"] = hashlib.sha256(html).hexdigest()
for path in ("topics", "member-tasks", "member-contents/9054"):
    try:
        urllib.request.urlopen("http://127.0.0.1:8080/api/admin/" + path, timeout=15)
    except urllib.error.HTTPError as error:
        out["unauthenticated_" + path] = error.code
        assert error.code == 401
    else:
        raise AssertionError("Protected admin route allowed unauthenticated access")
assets = subprocess.check_output(
    ["docker", "exec", "unspun-web-1", "find", "/srv/www/assets", "-maxdepth", "1", "-name", "AdminLayout-*.js"], text=True
).splitlines()
assert len(assets) == 1
bundle = subprocess.check_output(["docker", "exec", "unspun-web-1", "cat", assets[0]])
assert b"member-contents/" in bundle and b"/admin/topics" in bundle
out["admin_bundle"] = {"path": assets[0], "sha256": hashlib.sha256(bundle).hexdigest(), "topic_and_evidence_routes_present": True}
code = '''
import json
from sqlalchemy import text
from unspun.api.app import app
from unspun.api.admin.topics import list_topics, member_tasks
from unspun.core.config import get_settings
from unspun.core.db import get_engine
from sqlalchemy.orm import Session
settings=get_settings()
with get_engine().connect() as connection, connection.begin():
 connection.execute(text("SET TRANSACTION READ ONLY"))
 with Session(bind=connection) as session:
  topics=list_topics(session,q=None,status=None,page=1,page_size=20)
  tasks=member_tasks(session,topic_id=None,article_id=None,status=None,page=1,page_size=20)
  result={"read_only":connection.scalar(text("SHOW transaction_read_only")),"topic_count":topics["total"],"member_task_count":tasks["total"],"processing_enabled":topics["processing_enabled"],"admin_local_preview":settings.admin_local_preview,"routes":[path for path in app.openapi()["paths"] if path.startswith("/api/admin/topics") or path.startswith("/api/admin/member-")]}
print(json.dumps(result))
'''
out["api"] = json.loads(subprocess.check_output(["docker", "exec", "-i", "unspun-api-1", "python", "-"], input=code, text=True))
assert out["api"]["read_only"] == "on"
assert not out["api"]["admin_local_preview"] and not out["api"]["processing_enabled"]
assert out["api"]["topic_count"] == out["api"]["member_task_count"] == 0
print(json.dumps(out, indent=2))
