"""Run the remaining independent, read-only deployment probes."""
import gzip
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

CACHE = Path(__file__).parent
ROOT = Path('/Users/li.cong/.config/superpowers/worktrees/unspun/r2-member-completion')
before = json.loads((CACHE/'predeploy-production.json').read_text())
after = json.loads((CACHE/'postdeploy-production.json').read_text())
activity = gzip.decompress((ROOT/'docs/acceptance/r2-06-selection/ambient-production.py.gz').read_bytes()).decode()
activity = activity.replace('2026-10-21T09:46:32.373667+00:00',before['transaction']['at']).replace('2026-10-21T10:54:46.428747+00:00',after['transaction']['at'])
activity = activity.replace('t.kind,t.strategy_version','t.kind,t.article_id,t.strategy_version')
retained = json.loads((CACHE/'predeploy-retained.json').read_text())['tables']
counts = [(name,retained[name]['rows']) for name in ('content_identities','content_urls')]
prefix = '''
import json
from sqlalchemy import text
from unspun.core.db import get_engine
with get_engine().connect().execution_options(isolation_level='REPEATABLE READ') as connection, connection.begin():
 connection.execute(text('SET TRANSACTION READ ONLY'))
 out={'read_only':connection.scalar(text('SHOW transaction_read_only')),'preserved_prefixes':{},'provider_queries':0,'database_writes':0}
 for table,count in COUNTS:
  out['preserved_prefixes'][table]=dict(connection.execute(text(f"SELECT count(*) AS rows,md5(string_agg(to_jsonb(t)::text,'' ORDER BY to_jsonb(t)::text)) AS hash FROM (SELECT * FROM {table} ORDER BY id LIMIT {count}) t")).mappings().one())
 print(json.dumps(out,indent=2))
'''.replace('COUNTS',repr(counts))

def capture(name,code,host=False):
    command=['ssh','unspun','python3 -' if host else 'docker exec -i unspun-api-1 python -']
    result=subprocess.run(command,input=code,text=True,capture_output=True,check=True,timeout=60)
    data=json.loads(result.stdout)
    (CACHE/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
    print(name,flush=True)

with ThreadPoolExecutor(max_workers=3) as pool:
    pending=[pool.submit(capture,'ambient-production-activity',activity),pool.submit(capture,'retained-prefixes',prefix),pool.submit(capture,'postdeploy-admin',(CACHE/'admin-deployment-probe.py').read_text(),True)]
    for future in pending:
        future.result()
