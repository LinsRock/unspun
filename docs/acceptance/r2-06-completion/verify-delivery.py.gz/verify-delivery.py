"""Verify this delivery from retained read-only probes and immutable CI results."""
import hashlib
import json
import subprocess
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

CACHE = Path(__file__).parent
ROOT = Path('/Users/li.cong/.config/superpowers/worktrees/unspun/r2-member-completion')
def read(name):
    return json.loads((CACHE / (name + '.json')).read_text())

revision = read('core-merged')['mergeCommit']['oid']
ci = read('core-main-ci')
assert ci['headSha'] == revision and ci['conclusion'] == 'success'
assert read('core-pr-ci')['conclusion'] == 'success'
deploy = next(j for j in ci['jobs'] if j['name'] == 'deploy')
assert deploy['conclusion'] == 'success'
assert next(s for s in deploy['steps'] if s['name'] == 'Deploy')['conclusion'] == 'success'
runtime = read('postdeploy-runtime')
assert runtime['health'] == {'status': 'ok', 'version': revision, 'database': 'ok'}
assert runtime['legacy_workers'] == 0 and runtime['r1_workers'] == 1
containers = {row['name']: row for row in runtime['running_containers']}
for name in ('unspun-api-1', 'unspun-r1-worker-1', 'unspun-web-1'):
    assert containers[name]['image'].endswith(':' + revision)
    assert containers[name]['status'] == 'running'
assert containers['unspun-api-1']['image_id'] == containers['unspun-r1-worker-1']['image_id']
local = {str(path.relative_to(ROOT/'server/src/unspun')): hashlib.sha256(path.read_bytes()).hexdigest() for path in (ROOT/'server/src/unspun').rglob('*.py')}
assert runtime['api_metadata']['source_sha256'] == local
assert runtime['api_metadata']['config_sha256'] == read('predeploy-runtime')['api_metadata']['config_sha256']
chain = read('postdeploy-member-chain')
assert chain['schema'] == '000019'
assert not chain['configured_member_processing_enabled'] and not chain['runtime']['member_processing_enabled']
assert chain['member_handlers'] == chain['topic_tasks'] == chain['topic_calls'] == []
assert len(chain['tables']) == 7 and all(row['rows'] == 0 for row in chain['tables'].values())
assert chain['policy'] == read('predeploy-member-chain')['policy']
assert not any(name.startswith('topic_') for name in chain['policy']['stage_caps'])
for key in ('settings', 'runtime', 'retired_module_present', 'fixture_directory_present'):
    assert read('predeploy-boundaries')[key] == read('postdeploy-boundaries')[key]
ledgers = {}
for name in ('production', 'evaluation'):
    before, after = read('predeploy-' + name), read('postdeploy-' + name)
    assert after['transaction']['read_only'] == 'on'
    assert 'provider' not in before and 'provider' not in after
    assert before['policy'] == after['policy'] and before['carry'] == after['carry']
    prior = {row['id']: row for row in before['unknown_requests']}
    current = {row['id']: row for row in after['unknown_requests']}
    assert all(current[key] == value for key, value in prior.items())
    a, b = after['known_ledger'][0], before['known_ledger'][0]
    ledgers[name] = {'known_count_delta': a['requests'] - b['requests'], 'known_usd_delta': str(Decimal(a['known_usd']) - Decimal(b['known_usd'])), 'unknown_count': len(current), 'held_usd': str(sum((Decimal(row['reserved_usd']) for row in current.values()), Decimal(0))), 'new_unknown_ids': sorted(set(current) - set(prior))}
    if name == 'evaluation':
        assert a == b and current == prior
activity = read('ambient-production-activity')
calls = activity['calls']
assert all(row['stage'] == 'card' and row['strategy_version'] == 'r1-card-v9' for row in calls)
deployment_at = datetime.fromisoformat(containers['unspun-r1-worker-1']['started_at'].replace('Z', '+00:00'))
assert all(datetime.fromisoformat(row['ended_at']) < deployment_at for row in calls)
known = [row for row in calls if row['usage_id'] is not None]
unknown = [row for row in calls if row['status'] in ('reserved', 'usage_unknown')]
assert ledgers['production']['known_count_delta'] == len(known)
assert Decimal(ledgers['production']['known_usd_delta']) == sum((Decimal(str(row['cost_usd'])) for row in known), Decimal(0))
assert ledgers['production']['new_unknown_ids'] == sorted(row['id'] for row in unknown)
assert all(row['usage_id'] is None and row['reconciliation'] is None for row in activity['unresolved'])
before, after = read('predeploy-protected-production')['queries'], read('postdeploy-protected-production')['queries']
for key in before:
    if key not in ('usage', 'unknown'):
        assert before[key]['rows'] == after[key]['rows'], key
retained = read('predeploy-retained')['tables']
current = read('postdeploy-retained')['tables']
prefix = read('retained-prefixes')
for table in retained:
    if table in ('content_identities', 'content_urls'):
        assert prefix['preserved_prefixes'][table] == retained[table]
    else:
        assert retained[table] == current[table], table
before, after = read('predeploy-reading'), read('postdeploy-reading')
old_details = {row['id']: row for row in before['qualified_details_verified']}
new_details = {row['id']: row for row in after['qualified_details_verified']}
changed = {key for key, value in old_details.items() if new_details.get(key) != value}
assert changed == {9334}
material = read('material-retention')
assert material['read_only'] == 'on'
assert any(row['body_sha256'] == old_details[9334]['body_sha256'] for row in material['materials'])
current_material = next(row for row in material['materials'] if row['id'] == material['current_material_id'])
assert current_material['body_sha256'] == new_details[9334]['body_sha256']
assert datetime.fromisoformat(current_material['retrieved_at']) < deployment_at
assert any(row['article_id'] == 9334 for row in calls)
assert set(new_details) - set(old_details) == {9232, 9354, 9398, 9407}
assert (set(new_details) - set(old_details)).issubset({row['article_id'] for row in calls})
assert set(before['published_ids']).issubset(after['published_ids'])
for key in ('new_path_published', 'suspended_nyt_status'):
    assert before[key] == after[key]
observation = read('predeploy-observation')
assert observation['containers'] == read('postdeploy-observation')['containers']
assert observation['retained_files'] == read('postdeploy-observation')['retained_files']
manifest = json.loads((ROOT/'docs/acceptance/r2-06-selection/protected-manifest.json').read_text())
for name, digest in manifest['files'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, name
worktree = manifest['protected_worktree']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree['path'],text=True).strip() == worktree['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=worktree['path'],text=True) == worktree['status']
admin = read('postdeploy-admin')
assert admin['page_status'] == 200 and admin['admin_bundle']['topic_and_evidence_routes_present']
assert admin['api']['read_only'] == 'on' and not admin['api']['admin_local_preview']
result = {'at':datetime.now(UTC).isoformat(),'production_revision':revision,'delivery_checks':'passed','source_hashes_match':len(local),'schema':'000019','member_processing_enabled':False,'member_tasks_and_calls':0,'empty_member_tables':7,'new_stage_allocations':0,'legacy_workers':0,'r1_workers':1,'protected_original_details':len(old_details),'qualified_details':len(new_details),'reader_and_old_identity_url_rows_unchanged':True,'r204_containers_unchanged':len(observation['containers']),'r204_original_files_unchanged':len(observation['retained_files']),'protected_artifacts_unchanged':len(manifest['files']),'r204_worktree_unchanged':True,'ledgers':ledgers,'ambient_r1_calls':len(calls),'whole_production_window_zero_paid':not calls,'this_r206_work_generation':0,'this_r206_work_embedding':0,'this_r206_work_paid_retries':0,'provider_queries':0,'fee_reconciliation_or_hold_release':False,'new_blind_prepared_or_read':False,'r206_status':'3/4','real_v6_semantics':'unmeasured','user_acceptance':None}
result.update(delivery_checks='passed_with_explained_ambient_r1_activity',original_body_versions_retained=len(old_details),unchanged_current_details=len(old_details)-len(changed),ambient_refreshed_detail_ids=sorted(changed),ambient_new_detail_ids=sorted(set(new_details)-set(old_details)),ambient_activity_before_deployment=True,live_first_two_pages_identical=False)
result.pop('protected_original_details')
(CACHE/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
