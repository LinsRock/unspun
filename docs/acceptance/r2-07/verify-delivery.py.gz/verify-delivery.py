"""Verify immutable CI and read-only before/after production probes for R2-07."""
import hashlib,json,subprocess
from datetime import UTC,datetime
from decimal import Decimal
from pathlib import Path
ROOT=Path('/Users/li.cong/.config/superpowers/worktrees/unspun/r2-progress-overview')
CACHE=Path(__file__).parent
def read(name):return json.loads((CACHE/(name+'.json')).read_text())
merged=read('core-merged');revision=merged['mergeCommit']['oid']
ci=read('core-main-ci');assert ci['headSha']==revision and ci['conclusion']=='success'
assert read('core-pr-ci')['conclusion']=='success'
deploy=next(j for j in ci['jobs'] if j['name']=='deploy');assert deploy['conclusion']=='success'
assert next(s for s in deploy['steps'] if s['name']=='Deploy')['conclusion']=='success'
before_runtime,after_runtime=read('predeploy-runtime'),read('postdeploy-runtime')
assert after_runtime['health']=={'status':'ok','version':revision,'database':'ok'}
assert after_runtime['legacy_workers']==0 and after_runtime['r1_workers']==1
containers={r['name']:r for r in after_runtime['running_containers']}
previous={r['name']:r for r in before_runtime['running_containers']}
for name in ('unspun-api-1','unspun-r1-worker-1'):
 assert containers[name]['status']=='running' and containers[name]['image'].endswith(':'+revision)
assert containers['unspun-api-1']['image_id']==containers['unspun-r1-worker-1']['image_id']
assert containers['unspun-web-1']['image_id']==previous['unspun-web-1']['image_id']
for row in containers.values():
 for binds in row['published_ports'].values():
  assert binds is None or binds==[{'HostIp':'127.0.0.1','HostPort':'8080'}]
manifest=json.loads((ROOT/'docs/acceptance/r2-07/source-manifest.json').read_text())
assert after_runtime['api_metadata']['source_sha256']==manifest
assert after_runtime['api_metadata']['config_sha256']==before_runtime['api_metadata']['config_sha256']
chain=read('postdeploy-synthesis-chain');prior_chain=read('predeploy-synthesis-chain')
assert chain['read_only']=='on' and chain['schema']=='000020'
assert not any(chain[k] for k in ('configured_synthesis_enabled','configured_topic_publication_enabled','configured_member_processing_enabled'))
assert not chain['runtime']['synthesis_enabled'] and not chain['runtime']['member_processing_enabled']
assert chain['topic_handlers']==chain['topic_tasks']==chain['topic_calls']==[]
assert len(chain['tables'])==8 and all(v=={'exists':True,'rows':0} for v in chain['tables'].values())
assert chain['policy']==prior_chain['policy']
assert not any(k.startswith('topic_') for k in chain['policy']['stage_caps'])
before,after=read('predeploy-boundaries'),read('postdeploy-boundaries')
for key in ('settings','retired_module_present','fixture_directory_present'):assert before[key]==after[key]
assert before['runtime']=={k:v for k,v in after['runtime'].items() if k!='synthesis_enabled'}
ledgers={}
for name in ('production','evaluation'):
 a,b=read('predeploy-'+name),read('postdeploy-'+name)
 assert a['transaction']['read_only']==b['transaction']['read_only']=='on'
 assert 'provider' not in a and 'provider' not in b
 assert a['policy']==b['policy'] and a['carry']==b['carry']
 old={r['id']:r for r in a['unknown_requests']};new={r['id']:r for r in b['unknown_requests']}
 assert all(new.get(k)==v for k,v in old.items())
 delta=Decimal(b['known_ledger'][0]['known_usd'])-Decimal(a['known_ledger'][0]['known_usd'])
 ledgers[name]={'known_count_delta':b['known_ledger'][0]['requests']-a['known_ledger'][0]['requests'],'known_usd_delta':str(delta),'unknown_count':len(new),'held_usd':str(sum((Decimal(r['reserved_usd']) for r in new.values()),Decimal(0))),'prior_unknowns_preserved':len(old),'new_unknown_ids':sorted(set(new)-set(old))}
 if name=='evaluation':assert a['known_ledger']==b['known_ledger'] and old==new
activity=read('ambient-production')
calls=activity['calls'];known=[r for r in calls if r['usage_id'] is not None]
assert all(r['stage'] in ('card','guide') and r['strategy_version'].startswith('r1-') for r in calls)
assert len(known)==ledgers['production']['known_count_delta']
assert sum((Decimal(r['cost_usd']) for r in known),Decimal(0))==Decimal(ledgers['production']['known_usd_delta'])
assert sorted(r['id'] for r in calls if r['status'] in ('reserved','usage_unknown'))==ledgers['production']['new_unknown_ids']
a,b=read('predeploy-protected-production')['queries'],read('postdeploy-protected-production')['queries']
for key in a:
 if key not in ('schema','usage','unknown'):assert a[key]['rows']==b[key]['rows'],key
retained,current=read('predeploy-retained')['tables'],read('postdeploy-retained')['tables']
for table in retained:
 if table in ('content_identities','content_urls'):assert read('retained-prefixes')['tables'][table]==retained[table]
 else:assert current[table]==retained[table],table
old={r['id']:r for r in read('predeploy-reading')['qualified_details_verified']}
new={r['id']:r for r in read('postdeploy-reading')['qualified_details_verified']}
changed={k for k,v in old.items() if new.get(k)!=v}
materials=read('material-retention')['articles']
for key in changed:assert old[key]['body_sha256'] in materials[str(key)]['body_sha256']
new_ids=set(new)-set(old)
assert new_ids.issubset({r['article_id'] for r in calls})
for key in ('new_path_published','suspended_nyt_status'):
 assert read('predeploy-reading')[key]==read('postdeploy-reading')[key]
a,b=read('predeploy-observation'),read('postdeploy-observation')
assert a['containers']==b['containers'] and a['retained_files']==b['retained_files']
protected=json.loads((ROOT/'docs/acceptance/r2-06-selection/protected-manifest.json').read_text())
for name,digest in protected['files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
w=protected['protected_worktree'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w['path'],text=True).strip()==w['head'];assert subprocess.check_output(['git','status','--porcelain'],cwd=w['path'],text=True)==w['status']
result={'at':datetime.now(UTC).isoformat(),'production_revision':revision,'schema':'000020','delivery_checks':'passed','source_files_matched':len(manifest),'unchanged_web_image':containers['unspun-web-1']['image'],'new_chain_processing_and_publication_enabled':False,'topic_handlers_tasks_calls_allocations':0,'empty_topic_chain_tables':8,'legacy_workers':0,'r1_workers':1,'original_details':len(old),'current_qualified_details':len(new),'unchanged_current_details':len(old)-len(changed),'retained_original_body_versions':len(old),'ambient_changed_detail_ids':sorted(changed),'ambient_new_detail_ids':sorted(new_ids),'reader_and_old_identity_url_rows_unchanged':True,'ledgers':ledgers,'ambient_r1_calls':len(calls),'whole_production_window_zero_paid':not calls,'r204_containers_unchanged':len(a['containers']),'r204_original_files_unchanged':len(a['retained_files']),'protected_artifacts_unchanged':len(protected['files']),'r204_worktree_unchanged':True,'this_batch_generation':0,'this_batch_embedding':0,'this_batch_paid_retries':0,'provider_queries':0,'hold_release_or_reconciliation':False,'r206_status':'deferred; 3/4; real quality not accepted','r207_real_quality':'unmeasured','r207_overall_acceptance':False,'user_acceptance':None}
(CACHE/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
