from pathlib import Path
__file__='/Users/li.cong/.config/superpowers/worktrees/unspun/r2-progress-overview/docs/acceptance/r2-07/capture.py'
"""Read-only R2-06 evidence, reusing prior probes without restarting observers."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("phase", choices=("predeploy", "postdeploy", "final"))
args = parser.parse_args()
output = Path('/Users/li.cong/.cache/unspun-r207-20261023')


def capture_one(name, command, script, env=None):
    target = output / f"{args.phase}-{name}.json"
    if target.exists() or target.with_suffix(".json.gz").exists():
        print("Retained existing", target.name, flush=True)
        return
    result = subprocess.run(
        command,
        input=script,
        text=True,
        capture_output=True,
        check=True,
        timeout=240,
        env=env,
    )
    data = json.loads(result.stdout)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    print(target.name, hashlib.sha256(target.read_bytes()).hexdigest(), flush=True)


pool = ThreadPoolExecutor(max_workers=4)
pending = []
def capture(name, command, script, env=None):
    pending.append(pool.submit(capture_one, name, command, script, env))

remote_python = ["ssh", "unspun", "python3", "-"]
api_python = ["ssh", "unspun", "docker exec -i unspun-api-1 python -"]
for name, script in (
    ("runtime", "docs/acceptance/r2-03/deployment-probe.py"),
    ("reading", "docs/acceptance/r2-04/reading.py"),
    ("protected-production", "docs/acceptance/cl-01/protected-audit.py"),
    ("boundaries", "docs/acceptance/cl-01/runtime-boundaries.py"),
    ("retained", "docs/acceptance/r2-05/retained.py"),
    ("member-chain", "docs/acceptance/r2-06/member-chain-probe.py"),
):
    command = (
        remote_python
        if name == "runtime"
        else ["ssh", "unspun", "docker exec -i unspun-r1-worker-1 python -"]
        if name in ("boundaries", "member-chain")
        else api_python
    )
    capture(name, command, (ROOT / script).read_text())
production_probe = (ROOT / "docs/acceptance/r2-04/snapshot.py").read_text()
if True:
    # Reuse the retained credentialled lookup, with no further provider queries.
    provider_block = 'if mode == "production":\n    with httpx.Client('
    assert production_probe.count(provider_block) == 1
    production_probe = production_probe.replace(
        provider_block, "if False:  # Bounded provider queries already captured.\n    with httpx.Client("
    )
capture(
    "production",
    ["ssh", "unspun", "docker exec -i unspun-r1-worker-1 python - production"],
    production_probe,
)
environment = dict(
    os.environ,
    UNSPUN_DATABASE_URL="postgresql+psycopg://unspun:unspun@localhost:5432/unspun_quality_r1_20261016",
)
capture(
    "evaluation",
    [str(ROOT / "server/.venv/bin/python"), "-", "evaluation"],
    (ROOT / "docs/acceptance/r2-04/snapshot.py").read_text(),
    env=environment,
)
capture(
    "observation",
    remote_python,
    """
import hashlib, json, subprocess
from datetime import UTC, datetime
from pathlib import Path
ids = subprocess.check_output(["docker", "ps", "-aq"], text=True).split()
rows = json.loads(subprocess.check_output(["docker", "inspect", *ids]))
out = {"captured_at": datetime.now(UTC).isoformat(), "containers": []}
for row in rows:
    if "r204" not in row["Name"]:
        continue
    out["containers"].append({"id": row["Id"], "name": row["Name"], "image": row["Image"], "status": row["State"]["Status"], "started_at": row["State"]["StartedAt"], "restart_count": row["RestartCount"], "mounts": [{"source": m["Source"], "destination": m["Destination"], "rw": m["RW"]} for m in row["Mounts"]]})
base = Path("/home/leon/unspun-observations")
out["retained_files"] = {str(p.relative_to(base)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(base.rglob("*")) if p.is_file() and "r2-04" in str(p) and p.suffix not in (".log", ".tmp")}
print(json.dumps(out, indent=2))
""",
)

for future in pending:
    future.result()
pool.shutdown(wait=True)
