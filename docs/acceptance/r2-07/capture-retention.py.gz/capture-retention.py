"""Read-only production activity and original-material retention probe orchestration."""
import json,subprocess
from pathlib import Path
CACHE=Path(__file__).parent
pre=json.loads((CACHE/'predeploy-production.json').read_text())
retained=json.loads((CACHE/'predeploy-retained.json').read_text())['tables']
old=json.loads((CACHE/'predeploy-reading.json').read_text())['qualified_details_verified']
new=json.loads((CACHE/'postdeploy-reading.json').read_text())['qualified_details_verified']
latest={r['id']:r for r in new}
changed=[r['id'] for r in old if latest.get(r['id'])!=r]
script='''import hashlib,json
from sqlalchemy import text,select
from sqlalchemy.orm import Session
from unspun.core.db import get_engine
from unspun.core.models import ContentMaterial
start=START
limits=LIMITS
changed=CHANGED
out={}
with get_engine().connect().execution_options(isolation_level='REPEATABLE READ') as c,c.begin():
 c.execute(text('SET TRANSACTION READ ONLY'))
 out['read_only']=c.scalar(text('SHOW transaction_read_only'))
 out['calls']=[dict(r) for r in c.execute(text("SELECT b.id,b.stage,b.phase,b.status,b.article_id,b.started_at,b.ended_at,b.usage_id,b.reserved_usd::text AS reserved_usd,u.cost_usd::text AS cost_usd,t.strategy_version FROM billed_requests b LEFT JOIN llm_usage u ON u.id=b.usage_id LEFT JOIN pipeline_tasks t ON t.id=b.task_id WHERE b.started_at>=CAST(:start AS timestamptz) OR u.created_at>=CAST(:start AS timestamptz) ORDER BY b.started_at,b.id"),{'start':start}).mappings()]
 out['tables']={}
 for table,count in limits.items():
  out['tables'][table]=dict(c.execute(text("SELECT count(*) AS rows,md5(string_agg(to_jsonb(t)::text,'' ORDER BY to_jsonb(t)::text)) AS hash FROM (SELECT * FROM "+table+" ORDER BY id LIMIT :count) t"),{'count':count}).mappings().one())
 out['articles']={}
 with Session(bind=c) as s:
  for aid in changed:
   rows=list(s.scalars(select(ContentMaterial).where(ContentMaterial.article_id==aid).order_by(ContentMaterial.id)))
   out['articles'][str(aid)]={'material_ids':[m.id for m in rows],'body_sha256':[hashlib.sha256('\\n'.join(p['text'] for p in m.paragraphs).encode()).hexdigest() for m in rows]}
 out.update(database_writes=0,provider_queries=0)
 print(json.dumps(out,indent=2,default=str))
'''
script=script.replace('START',repr(pre['transaction']['at'])).replace('LIMITS',repr({k:retained[k]['rows'] for k in ('content_identities','content_urls')})).replace('CHANGED',repr(changed))
result=subprocess.run(['ssh','unspun','docker exec -i unspun-api-1 python -'],input=script,text=True,capture_output=True,check=True,timeout=120)
data=json.loads(result.stdout)
for name in ('ambient-production','retained-prefixes','material-retention'):
 (CACHE/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
(CACHE/'retention-probe.py').write_text(script)
print('Read-only calls',len(data['calls']),'changed detail IDs',changed)
