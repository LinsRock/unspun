import hashlib,json
from sqlalchemy import text,select
from sqlalchemy.orm import Session
from unspun.core.db import get_engine
from unspun.core.models import ContentMaterial
start='2026-10-23 05:53:39.180310+00:00'
limits={'content_identities': 821, 'content_urls': 870}
changed=[]
out={}
with get_engine().connect().execution_options(isolation_level='REPEATABLE READ') as c,c.begin():
 c.execute(text('SET TRANSACTION READ ONLY'))
 out['read_only']=c.scalar(text('SHOW transaction_read_only'))
 out['calls']=[dict(r) for r in c.execute(text("SELECT b.id,b.stage,b.phase,b.status,b.article_id,b.started_at,b.ended_at,b.usage_id,b.reserved_usd::text AS reserved_usd,u.cost_usd::text AS cost_usd,t.strategy_version FROM billed_requests b LEFT JOIN llm_usage u ON u.id=b.usage_id LEFT JOIN pipeline_tasks t ON t.id=b.task_id WHERE b.started_at>=CAST(:start AS timestamptz) OR u.created_at>=CAST(:start AS timestamptz) ORDER BY b.started_at,b.id"),{'start':start}).mappings()]
 out['tables']={}
 for table,count in limits.items():
  out['tables'][table]=dict(c.execute(text("SELECT count(*) AS rows,md5(string_agg(to_jsonb(t)::text,'' ORDER BY to_jsonb(t)::text)) AS hash FROM (SELECT * FROM "+table+" ORDER BY id LIMIT :count) t"),{'count':count}).mappings().one())
 out['articles']={}
 with Session(bind=c) as s:
  for aid in changed:
   rows=list(s.scalars(select(ContentMaterial).where(ContentMaterial.article_id==aid).order_by(ContentMaterial.id)))
   out['articles'][str(aid)]={'material_ids':[m.id for m in rows],'body_sha256':[hashlib.sha256('\n'.join(p['text'] for p in m.paragraphs).encode()).hexdigest() for m in rows]}
 out.update(database_writes=0,provider_queries=0)
 print(json.dumps(out,indent=2,default=str))
