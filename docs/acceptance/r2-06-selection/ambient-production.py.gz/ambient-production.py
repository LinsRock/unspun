"""Read-only attribution of pre-deployment R1 activity; no provider lookup."""
import json
from sqlalchemy import text
from unspun.core.db import get_engine
with get_engine().connect().execution_options(isolation_level='REPEATABLE READ') as conn, conn.begin():
 conn.execute(text('SET TRANSACTION READ ONLY'))
 calls=[dict(r) for r in conn.execute(text('''SELECT b.id,b.started_at,b.ended_at,b.stage,b.phase,b.purpose,b.model,b.status,b.reserved_usd,b.provider_generation_id,b.http_status,b.task_id,b.task_attempt_id,b.usage_id,u.cost_usd,t.kind,t.strategy_version,t.created_at AS task_created_at,a.worker,b.error FROM billed_requests b LEFT JOIN llm_usage u ON u.id=b.usage_id LEFT JOIN pipeline_tasks t ON t.id=b.task_id LEFT JOIN task_attempts a ON a.id=b.task_attempt_id WHERE b.started_at>=:start AND b.started_at<=:end ORDER BY b.started_at,b.id'''),{'start':'2026-10-21T09:46:32.373667+00:00','end':'2026-10-21T10:54:46.428747+00:00'}).mappings()]
 protected=[dict(r) for r in conn.execute(text('''SELECT id,status,reserved_usd,usage_id,reconciliation,provider_generation_id,started_at FROM billed_requests WHERE status IN ('reserved','usage_unknown') ORDER BY id''')).mappings()]
 print(json.dumps({'read_only':conn.scalar(text('SHOW transaction_read_only')),'calls':calls,'unresolved':protected,'provider_queries':0,'database_writes':0},indent=2,default=str))
