"""Verify pre-existing identity/URL prefixes and attribute newly published R1 cards."""
import json
from sqlalchemy import text
from unspun.core.db import get_engine
with get_engine().connect().execution_options(isolation_level='REPEATABLE READ') as c, c.begin():
 c.execute(text('SET TRANSACTION READ ONLY'))
 out={'read_only':c.scalar(text('SHOW transaction_read_only')),'preserved_prefixes':{},'new_rows':{}}
 for table,count in (('content_identities',522),('content_urls',563)):
  out['preserved_prefixes'][table]=dict(c.execute(text(f"SELECT count(*) AS rows,md5(string_agg(to_jsonb(t)::text,'' ORDER BY to_jsonb(t)::text)) AS hash FROM (SELECT * FROM {table} ORDER BY id LIMIT {count}) t")).mappings().one())
  out['new_rows'][table]=[dict(r) for r in c.execute(text(f'SELECT * FROM {table} ORDER BY id OFFSET {count}')).mappings()]
 out['card_calls']=[dict(r) for r in c.execute(text("SELECT b.id,b.task_id,t.article_id,b.stage,b.phase,b.status,b.started_at,b.ended_at FROM billed_requests b JOIN pipeline_tasks t ON t.id=b.task_id WHERE t.article_id IN (9058,9282) AND b.started_at>='2026-10-21T09:46:32Z' ORDER BY b.started_at")).mappings()]
 out['derivations']=[dict(r) for r in c.execute(text("SELECT id,article_id,material_id,kind,status,created_at FROM content_derivations WHERE article_id IN (9058,9282) ORDER BY id")).mappings()]
 out.update(provider_queries=0,database_writes=0)
 print(json.dumps(out,indent=2,default=str))
